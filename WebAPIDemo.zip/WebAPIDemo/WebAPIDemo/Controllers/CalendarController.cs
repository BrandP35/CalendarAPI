﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CalendarDataAccess;

namespace WebAPIDemo.Controllers
{
    public class CalendarController : ApiController
    {
        public IEnumerable<Calendar> Get()
        {
            using(CalendarDbEntities entities = new CalendarDbEntities())
            {
                return entities.Calendars.ToList();
            }
        }

        public HttpResponseMessage Get(int id)
        {
            using (CalendarDbEntities entities = new CalendarDbEntities())
            {
                var entity = entities.Calendars.FirstOrDefault(e => e.CalendarId == id);

                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, "The Calendar is not posted!");
                }
            }
            
        }

        public HttpResponseMessage Post([FromBody] Calendar calendar)
        {
            try
            {
                using(CalendarDbEntities entities = new CalendarDbEntities())
                {
                    entities.Calendars.Add(calendar);
                    entities.SaveChanges();

                    var message = Request.CreateResponse(HttpStatusCode.Created, calendar);
                    message.Headers.Location = new Uri(Request.RequestUri + calendar.CalendarId.ToString());
                    return message;
                }
            }
            catch(Exception Ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, Ex);
            }
        }
    }
}
